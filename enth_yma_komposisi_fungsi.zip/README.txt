ENTHYMA — WEBSITE KOMPOSISI FUNGSI

Isi utama:
- index.html: website responsif satu file, dengan desain bertema laut dan navigasi interaktif.

Cara mencoba:
1. Unduh ZIP lalu ekstrak.
2. Buka index.html menggunakan browser.
3. Menu Materi, Mari Kita Coba, Mini Games, Final Test, dan Petunjuk Penggunaan sudah terhubung.
4. Tidak memerlukan instalasi pustaka eksternal.

Cara mengunggah ke GitHub Pages:
1. Buka repository GitHub milikmu.
2. Unggah file index.html ke folder utama (root), bukan file ZIP.
3. Buka Settings > Pages.
4. Pilih Deploy from a branch, branch main, folder /(root), lalu Save.
5. Setelah selesai dipublikasikan, buka tautan GitHub Pages yang ditampilkan.

Catatan:
- Website dirancang mobile-first dan dapat dibuka di browser HP maupun komputer.
- Skor/progres disimpan secara lokal pada browser perangkat.
